<?php

namespace App\Http\Controllers;

use App\Models\PublikasiJurnal;
use Illuminate\Http\Request;

class PublikasiJurnalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PublikasiJurnal  $publikasiJurnal
     * @return \Illuminate\Http\Response
     */
    public function show(PublikasiJurnal $publikasiJurnal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PublikasiJurnal  $publikasiJurnal
     * @return \Illuminate\Http\Response
     */
    public function edit(PublikasiJurnal $publikasiJurnal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PublikasiJurnal  $publikasiJurnal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PublikasiJurnal $publikasiJurnal)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PublikasiJurnal  $publikasiJurnal
     * @return \Illuminate\Http\Response
     */
    public function destroy(PublikasiJurnal $publikasiJurnal)
    {
        //
    }
}
